<div style="text-align: center;border-bottom: 2px solid #ccc;box-shadow: 5px 5px 5px 5px #eee;">
	<img src="https://www.maamarts.com/images/logo3.png" style="    width: 200px;">
</div>

<div class="jumbotron text-center">


  <h4>Hello, </h4>
 <p>Someone just showed interest.</p>
<p>Here are the details :</p>
 <br><br><br>
 <p><b>Name: </b> <?php echo $name;?></p>
 <p><b>Type: </b> <?php echo $type;?></p>
 <p><b>Subject: </b> <?php echo $subject;?></p> 
 <p><b>Email: </b> <?php echo $email;?></p>
 <p><b>Phone: </b> <?php echo $phone;?></p>
 <p><b>Message: </b> <?php echo $query;?></p> 
 <br><br><br>
 
</div>
  <div class="jumbotron text-center" style="text-align:left;margin-top:100px;">
 Warm Regard’s, <br>
Maam Arts
  
  </div>
<div style="background-color:#e6b506;padding: 25px;text-align: center;">&copy; <?php echo date("Y")?>. All Rights reserved Maam Arts</div>