<!doctype html>
<html>
   <head>
      <title>Coming Soon</title>
      <meta charset="utf-8">  
      <meta name="viewport" content="width=device-width, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"> 
      <link rel="stylesheet" href="<?php echo url("css/bootstrap.min.css");?>">
       
       
       
   </head>

   <body id="home" style="background: url(<?php echo url("images/summer.jpg");?>);
    background-size: cover;
    background-repeat: no-repeat;
    background-position: center center;">
      
      <div id="header">
      <div class="header-content" style=" 
    vertical-align: bottom;
    padding: 50px 0 10px 0;
    text-align: center;">
         <div class="countdown" id="countdown" style=" 
    color: #FFF;
    background: rgb(255 255 255 / 60%);
    padding: 20px 0;
    margin-top: 60vh;
 ">
            <div class="container">
                 <div class="row justify-content-center text-center">
                   <img src="<?php echo url("images/logo1.png");?>"  height="200px"> 
               </div>
            <div class="row">
                
            </div>   
            </div>
         </div>
          
          
      </div>
      </div>
         
       
   </body>
</html>