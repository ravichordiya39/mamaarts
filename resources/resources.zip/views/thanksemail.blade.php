<div style="text-align: center;border-bottom: 2px solid #ccc;box-shadow: 5px 5px 5px 5px #eee;">
	<img src="https://www.maamarts.com/images/logo3.png" style="    width: 200px;">
</div>

<div class="jumbotron text-center">
  <h4>Dear! <?php echo $name;?> </h4>
 <p>Thank you for connecting.</p>
 <p>We will get in touch soon.
</p>

 
</div>
  <div class="jumbotron text-center" style="text-align:left;margin-top:100px;">
 Warm Regard’s, <br>
Maam Arts
  
  </div>
<div style="background-color:#e6b506;padding: 25px;text-align: center;">&copy; <?php echo date("Y")?>. All Rights reserved Maam Arts</div>