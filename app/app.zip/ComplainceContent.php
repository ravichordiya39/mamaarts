<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ComplainceContent extends Model
{
    protected $table = 'complaincecontent';
}
