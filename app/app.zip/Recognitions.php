<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Recognitions extends Model
{
     protected $table = 'recognitions';
}
