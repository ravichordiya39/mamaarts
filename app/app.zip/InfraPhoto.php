<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class InfraPhoto extends Model
{
    protected $table = 'infraphoto';
}
