<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class WeThePeople extends Model
{
     protected $table = 'wethepeople';
}
