<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class BusinessPara extends Model
{
     protected $table = 'ourbusinesspara';
}
