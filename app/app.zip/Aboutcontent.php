<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Aboutcontent extends Model
{
      protected $table = 'about';
}
