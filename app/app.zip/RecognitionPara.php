<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class RecognitionPara extends Model
{
    protected $table = 'recognitionpara';
}
