<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Clientslogo extends Model
{
    protected $table='clientslogo';
}
