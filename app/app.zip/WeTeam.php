<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class WeTeam extends Model
{
     protected $table = 'weteam';
}
