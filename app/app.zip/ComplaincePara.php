<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ComplaincePara extends Model
{
    protected $table = 'complaincepara';
}
