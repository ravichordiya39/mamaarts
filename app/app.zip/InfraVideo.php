<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class InfraVideo extends Model
{
     protected $table = 'infravideo';
}
