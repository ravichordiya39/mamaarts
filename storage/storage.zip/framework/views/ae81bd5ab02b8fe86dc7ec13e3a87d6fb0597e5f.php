

<?php $__env->startSection('content'); ?>
<section id="about" class="page-section section-class container top-sec" >
                  <div class="sec-title centered">
                     <h2>Our Blogs</h2>
                     <div class="separator"><span></span></div>
                  </div>
                  <div class="row gallery">
				   <?php foreach($vg as $v)
				 {?><?php 
                   ?>
                          <div class="single-video col-md-4">
                           <a href="<?php echo url("read-post/".$v->slug);?>"><img src="<?php echo url("uploads/".$v->image)?>" style="width:100%"></a>
                            <a href="<?php echo url("read-post/".$v->slug);?>"><h4><?php echo $v->title;?></h4></a>
                            <a href="<?php echo url("read-post/".$v->slug);?>"><p style="color:#000;height:60px;"><?php echo mb_strimwidth($v->description, 0, 100, "...");?></p></a>
							<a href="<?php echo url("read-post/".$v->slug);?>" class="btn btn-danger">Read More..</a>
                          </div>
					 <?php } ?>
                          




 
 
                       
                  </div>
               </section>
			   
			   

 
			   <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.innerpages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/maamarts/public_html/resources/views/blogs.blade.php ENDPATH**/ ?>