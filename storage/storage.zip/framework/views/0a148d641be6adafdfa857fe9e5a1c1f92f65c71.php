

<?php $__env->startSection('content'); ?>
<section id="about" class="page-section section-class container top-sec" >
                  <div class="sec-title centered">
                     <h2><?php echo $post->title?></h2>
                     <div class="separator"><span></span></div>
                  </div>
                  <div class="row gallery">
				   <div class="col-md-8">
				   <?php echo $post->description;?>
				   </div>
                    <div class="col-md-4">
				   <img src="<?php echo url("uploads/".$post->image)?>" style="width:100%">
				   </div>      
                       
                  </div>
               </section>
			   
			   

 
			   <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.innerpages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/maamarts/public_html/resources/views/blogs_details.blade.php ENDPATH**/ ?>